﻿
    using System;
    using System.ComponentModel.DataAnnotations;

    namespace LibraryManagementAPI.Models
    {
        public class Student
        {
            [Key]
            public int StudentID { get; set; }

            [Required]
            [MaxLength(100)]
            public required string StudentName { get; set; }

            public DateTime DOB { get; set; }

            [Required]
            [EmailAddress]
            [MaxLength(100)]
            public required string Email { get; set; }
        }
    }
